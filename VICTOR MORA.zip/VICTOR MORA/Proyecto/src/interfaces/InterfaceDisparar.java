package interfaces;

public interface InterfaceDisparar {

	public void disparar();
	
}
