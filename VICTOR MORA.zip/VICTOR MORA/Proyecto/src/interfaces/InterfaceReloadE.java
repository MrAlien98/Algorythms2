package interfaces;

public interface InterfaceReloadE {

	public void reloadE();
	
}
