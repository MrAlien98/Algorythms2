package vistaControl;

import java.text.NumberFormat;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class ParqueoPublicoController {
	
	@FXML private NumberFormat CURRENCY=NumberFormat.getCurrencyInstance();
	
	@FXML private ChoiceBox<String> tipoVehiculoChoiceBox;
	
	@FXML private TextField horaInicioTextField;
	@FXML private TextField horaFinalTextField;
	@FXML private TextField valorAPagarTextField;
	
	@FXML private Button calcularButton;
	
	
	public void initialize() {
		calcularButton.setOnMouseClicked(e->{
			calcularButtonPresionad(e);
		});
		
		tipoVehiculoChoiceBox.setItems(FXCollections.observableArrayList("Carro", "Moto"));
		tipoVehiculoChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observableValue, Number number, Number number2) {
				ParqueoPublico.darParqueadero().marcarHoraInicio(tipoVehiculoChoiceBox.getItems().get((Integer) number2));
				horaInicioTextField.setText(ParqueoPublico.darParqueadero().darHoraInicio());
			}
		});

	}
	
	public void calcularButtonPresionad(MouseEvent event) {
		ParqueoPublico.darParqueadero().marcarHoraFinal();
		horaFinalTextField.setText(ParqueoPublico.darParqueadero().darHoraFinal());
//		valorAPagarTextField.setText(Double.toHexString(ParqueoPublico.darParqueadero().calcularValorAPagar()));
		valorAPagarTextField.setText("$"+ParqueoPublico.darParqueadero().calcularValorAPagar());
	}
	
}
