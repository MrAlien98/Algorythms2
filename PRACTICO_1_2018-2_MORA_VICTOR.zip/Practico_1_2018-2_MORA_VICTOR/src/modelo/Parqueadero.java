package modelo;

public class Parqueadero {

	public static final double TARIFA_HORA_MOTO=1000;
	public static final double TARIFA_HORA_CARRO=3500;
	public static final String MOTO="Moto";
	public static final String CARRO="Carro";
	
	private String tipoVehiculo;
	
	private int horaInicio;
	private int minutoInicio;
	
	private int horaFinal;
	private	int minutoFinal;
	
	public Parqueadero() {

	}
	
	public void marcarHoraInicio(String tipoV) {
		tipoVehiculo=tipoV;
		horaInicio=(int)(7+Math.random()*5);
		minutoInicio=(int)(Math.random()*60);
	}

	public String darHoraInicio() {
		return horaInicio+":"+minutoInicio;
	}
	
	public void marcarHoraFinal() {
		horaFinal=(int)(12+Math.random()*10);
		minutoFinal=(int)(Math.random()*60);
	}
	
	public double calcularValorAPagar() {
		double tarifa;
		if(tipoVehiculo.equals(MOTO)) {
			tarifa=TARIFA_HORA_MOTO;
		}else {
			tarifa=TARIFA_HORA_CARRO;
		}
		double valorAPagar=(horaFinal-horaInicio)*tarifa;
		if(minutoFinal>minutoInicio) {
			valorAPagar+=tarifa;
		}
		return valorAPagar;
	}
	
	public String getTipoVehiculo() {
		return tipoVehiculo;
	}

	public void setTipoVehiculo(String tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}

	public void setHoraInicio(int horaInicio) {
		this.horaInicio = horaInicio;
	}

	public int getMinutoInicio() {
		return minutoInicio;
	}

	public void setMinutoInicio(int minutoInicio) {
		this.minutoInicio = minutoInicio;
	}

	public String darHoraFinal() {
		return horaFinal+":"+minutoFinal;
	}

	public void setHoraFinal(int horaFinal) {
		this.horaFinal = horaFinal;
	}

	public int getMinutoFinal() {
		return minutoFinal;
	}

	public void setMinutoFinal(int minutoFinal) {
		this.minutoFinal = minutoFinal;
	}
	
	
	
}
