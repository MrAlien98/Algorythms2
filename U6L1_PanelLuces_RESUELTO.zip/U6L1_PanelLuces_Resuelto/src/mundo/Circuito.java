package mundo;

import java.awt.Color;
import java.io.*;
import java.util.Properties;
import java.util.Random;

public class Circuito {

	public static final int TAMANO_PANEL=9;
	
	private Bombillo[][] bombillos;
	
	public Circuito() {
		bombillos = new Bombillo[TAMANO_PANEL][TAMANO_PANEL];

	}
	
	public int[][] darColorBombillos() {
		int[][] color = new int[9][9];

		for (int i = 0; i < TAMANO_PANEL; i++) {
			for (int j = 0; j < TAMANO_PANEL; j++) {
				Bombillo bombillo = bombillos[i][j];
				// convenciones  blanco = 0, amarillo = 1, verde = 2, rojo = 3, azul = 4
				if (bombillo.darPrendido()==false) {
					color[i][j] = 0;
				} else if (bombillo.darColor().equals(Color.YELLOW)) {
					color[i][j] = 1;
				}else if (bombillo.darColor().equals(Color.GREEN)) {
					color[i][j] = 2;
				}else if (bombillo.darColor().equals(Color.RED)) {
					color[i][j] = 3;
				}else if (bombillo.darColor().equals(Color.BLUE)) {
					color[i][j] = 4;
				}
			}
		}
		return color;
	}
	
	public int cantidadBombillosApagados() {
		// TODO
		int contador = 0;
		for (int i = 0; i < TAMANO_PANEL; i++) {
			for (int j = 0; j < TAMANO_PANEL; j++) {
				if (bombillos[i][j] != null && !bombillos[i][j].darPrendido())
					contador++;
			}
		}
		return contador;
	}
	
	public int cantidadBombillosPrendidosPorColor(int color) {
		// TODO
		int contador = 0;
		switch (color) {
		// Amarillo
		case 1:
			for (int i = 0; i < TAMANO_PANEL; i++) {
				for (int j = 0; j < TAMANO_PANEL; j++) {
					if (bombillos[i][j] != null
							&& bombillos[i][j].darColor().equals(Color.YELLOW) && bombillos[i][j].darPrendido())
						contador++;
				}
			}
			break;
			//VERDE
		case 2:
			for (int i = 0; i < TAMANO_PANEL; i++) {
				for (int j = 0; j < TAMANO_PANEL; j++) {
					if (bombillos[i][j] != null
							&& bombillos[i][j].darColor().equals(Color.GREEN)&& bombillos[i][j].darPrendido())
						contador++;
				}
			}
			break;
			//ROJO
		case 3:
			for (int i = 0; i < TAMANO_PANEL; i++) {
				for (int j = 0; j < TAMANO_PANEL; j++) {
					if (bombillos[i][j] != null
							&& bombillos[i][j].darColor().equals(Color.RED) && bombillos[i][j].darPrendido())
						contador++;
				}
			}
			break;
			//AZUL
		case 4:
			for (int i = 0; i < TAMANO_PANEL; i++) {
				for (int j = 0; j < TAMANO_PANEL; j++) {
					if (bombillos[i][j] != null
							&& bombillos[i][j].darColor().equals(Color.BLUE) && bombillos[i][j].darPrendido())
						contador++;
				}
			}
			break;
		}
		return contador;
	}
	
	
	public void prenderBombillo(int posX, int posY) {
		// TODO
		if (bombillos[posX][posY] != null
				&& bombillos[posX][posY].darPrendido() == false)
			bombillos[posX][posY].prender();
	}


	/**
	 * Nombre: primerBombilloApagado
	 * Descripci�n: Este m�todo verifica y retorna el primer bombillo que encuentra apagado 
	 * <b>Pre:</b> la matriz de bombillos est� inicializada y llena
	 * @return Bombillo � primer bombillo apagado
     */

	public Bombillo primerBombilloApagado() {
		// TODO
		Bombillo obj = null;
		boolean termino = false;

		for (int i = 0; i < TAMANO_PANEL && !termino; i++) {
			for (int j = 0; j < TAMANO_PANEL && !termino; j++) {
				if (bombillos[i][j] != null
						&& bombillos[i][j].darPrendido() == false) {
					obj = bombillos[i][j];
					termino = true;
				}
			}
		}
		return obj;
	}
	/**
	 * nombre: inicializarCircuito 
	 * Descripci�n: Este m�todo permite leer la informaci�n de un objeto Properties y actualizar la matriz de bombillos
	 * <b>Pre:</b> la matriz bombillos != null
	 * @param informacion: es el objeto tipo Properties, informacion !=null,
	 * <b>Pos:</b> La matriz llena de bombillos
	 * @throws Exception No se puede cargar la matriz de bombillos          
	 */
	
	public void inicializarCircuito() {
		// TODO
		boolean prendido = false;
		// Soluci�n

		for (int i = 0; i < TAMANO_PANEL; i++) {
			for (int j = 0; j < TAMANO_PANEL; j++) {
				int color = 1 + (int) (Math.random() * (5 - 1));
				prendido = new Random().nextBoolean();
				bombillos[i][j] = new Bombillo(color, prendido, i, j);
			}
		}
	}

	
	public boolean estaPrendido(int x, int y) {

		if (bombillos[x][y]!=null && bombillos[x][y].darPrendido()) {
			return true;
		}
		return false;
	}

}
