package mundo;

import java.awt.*;

public class Bombillo {

	private Color color;
	private boolean prendido;
	private int posX;
	private int posY;

	public Bombillo(int pColor, boolean prend, int posicionX, int posicionY) {
		// validar el color de bombillo y posici�n
		// convenciones blanco = 0, amarillo = 1, verde = 2, rojo = 3, azul = 4
		// System.out.println(pColor);
		switch (pColor) {
		case 1:
			color = Color.YELLOW;
			prendido = prend;
			posX = posicionX;
			posY = posicionY;
			break;
		case 2:
			color = Color.GREEN;
			prendido = prend;
			posX = posicionX;
			posY = posicionY;
			break;
		case 3:
			color = Color.RED;
			prendido = prend;
			posX = posicionX;
			posY = posicionY;
			break;
		case 4:
			color = Color.BLUE;
			prendido = prend;
			posX = posicionX;
			posY = posicionY;
			break;
		}
	}

	// m�todos dar
	public Color darColor() {
		return color;
	}

	public boolean darPrendido() {
		return prendido;
	}

	// m�todos cambiar
	public void cambiarColor(Color color) {
		this.color = color;

	}

	public void cambiarPrendido(boolean prendido) {
		this.prendido = prendido;

	}

	public void prender() {
		prendido = true;
	}

	public void apagar() {
		prendido = false;
	}

	public int darPosX() {
		return posX;
	}

	public int darPosY() {
		return posY;
	}

}
