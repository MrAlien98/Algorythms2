package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import mundo.Circuito;

public class PanelJuego extends JPanel {

	private InterfazBombillos principal;
	private JLabel [][] panel;

	
	public PanelJuego(InterfazBombillos ventana){
		
		principal = ventana;
		setBorder(BorderFactory.createTitledBorder("Panel "));
		JPanel panelLuces= new JPanel();
		panelLuces.setLayout(new GridLayout(Circuito.TAMANO_PANEL,Circuito.TAMANO_PANEL));
		panelLuces.setBorder(BorderFactory.createLineBorder( new Color(0,0,0) ));
		setLayout(new BorderLayout());
		panel = new JLabel[Circuito.TAMANO_PANEL][Circuito.TAMANO_PANEL];
		for(int i=0; i < Circuito.TAMANO_PANEL; i ++){
			for(int j=0; j < Circuito.TAMANO_PANEL; j ++){
				panel[i][j] = new JLabel("");
				Border border = BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.BLACK,
				        Color.BLACK);
				panel[i][j].setBorder(border);
				panelLuces.add(panel[i][j]);
				
			}
			add(panelLuces, BorderLayout.CENTER);
		}

	}

	public void cargarPanel() {
		int[][] bombillos = principal.darColorBombillos();
		for (int i = 0; i < Circuito.TAMANO_PANEL; i++) {
			for (int j = 0; j < Circuito.TAMANO_PANEL; j++) {
				// convenciones blanco = 0, amarillo = 1, verde = 2, rojo = 3,
				// azul = 4
				switch (bombillos[i][j]) {
				case 0:
					panel[i][j].setHorizontalAlignment(JLabel.CENTER);
					panel[i][j].setIcon(new ImageIcon("./data/imagenes/white.gif"));					
					break;
				case 1:
					panel[i][j].setHorizontalAlignment(JLabel.CENTER);
					panel[i][j].setIcon(new ImageIcon("./data/imagenes/yellow.gif"));					
					break;
				case 2:
					panel[i][j].setIcon(new ImageIcon("./data/imagenes/green.gif"));
					panel[i][j].setHorizontalAlignment(JLabel.CENTER);
					break;
				case 3:
					panel[i][j].setIcon(new ImageIcon("./data/imagenes/red.gif"));
					panel[i][j].setHorizontalAlignment(JLabel.CENTER);
					break;
				case 4:
					panel[i][j].setIcon(new ImageIcon("./data/imagenes/blue.gif"));
					panel[i][j].setHorizontalAlignment(JLabel.CENTER);
					break;
				}

			}

		}

	}
	
}

