package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import mundo.Circuito;
import mundo.Bombillo;

public class InterfazBombillos extends JFrame{
	
	private PanelJuego pJuego;
	private Circuito circuito;
	
	private PanelJuego pJuegoSol;
	private PanelDatos pDatos;
	private JPanel base;
	
	public InterfazBombillos() {
		// TODO Auto-generated constructor stub
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Panel de Luces");
		setLayout(new BorderLayout());
		setSize(488, 480);
		
	
		JLabel encabezado = new JLabel(new ImageIcon(
				"./data/imagenes/encabezado.png"));
		pJuegoSol = new PanelJuego(this);
		// pJuego = new PanelJuego(this);
		pDatos = new PanelDatos(this);
		base = new JPanel();
		base.setLayout(new GridLayout(1, 2));
		base.add(pJuegoSol);
		base.add(pDatos);
		add(encabezado, BorderLayout.NORTH);
		add(base, BorderLayout.CENTER);
		inicializarMundo();		
		

	}
	
	public void inicializarMundo(){
			circuito= new Circuito();
			circuito.inicializarCircuito();
			pJuegoSol.cargarPanel();
			int cantApagados = circuito.cantidadBombillosApagados();
			int cantAzul = circuito.cantidadBombillosPrendidosPorColor(4);
			int cantVerde = circuito.cantidadBombillosPrendidosPorColor(2);
			int cantAmarillo = circuito.cantidadBombillosPrendidosPorColor(1);
			int cantRojo = circuito.cantidadBombillosPrendidosPorColor(3);
			pDatos.refrescarCantBomb(cantApagados, cantAzul, cantVerde, cantAmarillo, cantRojo);
		
	}
	
	public void prenderBombillo() {
		try {
			int x = Integer.parseInt(pDatos.darPosX());
			x--;
			int y = Integer.parseInt(pDatos.darPosY());
			y--;
			
			if(circuito.estaPrendido(x,y)){
				JOptionPane.showMessageDialog(this,
						"El bombillo ya est� prendido", "Informaci�n",
						JOptionPane.INFORMATION_MESSAGE);
			}else {				
				circuito.prenderBombillo(x, y);
				pJuegoSol.cargarPanel();
				int cantApagados = circuito.cantidadBombillosApagados();
				int cantAzul = circuito.cantidadBombillosPrendidosPorColor(4);
				int cantVerde = circuito.cantidadBombillosPrendidosPorColor(2);
				int cantAmarillo = circuito.cantidadBombillosPrendidosPorColor(1);
				int cantRojo = circuito.cantidadBombillosPrendidosPorColor(3);
				pDatos.refrescarCantBomb(cantApagados, cantAzul, cantVerde,
						cantAmarillo, cantRojo);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"Las posiciones son incorrectas", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	public void primerBombilloApagado(){
		Bombillo b= circuito.primerBombilloApagado();
		pDatos.refrescarPosiciones(b.darPosX()+1, b.darPosY()+1);
	}
	
	public int [][] darColorBombillos(){
		return circuito.darColorBombillos();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfazBombillos ventana = new InterfazBombillos();
		ventana.setVisible(true);

	}

}
