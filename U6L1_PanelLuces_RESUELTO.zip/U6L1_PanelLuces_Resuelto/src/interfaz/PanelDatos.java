package interfaz;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PanelDatos extends JPanel implements ActionListener{
	
	private static final String PRENDER= "prender";
	private static final String PRIMER= "primer";
	
	private JLabel labCantBomb;
	private JLabel labPosX;
	private JLabel labPosY;
	private JTextField txtCantBomb;
	private JTextField txtPosX;
	private JTextField txtPosY;
	private JButton botPrender;
	private JButton botPrimer;
	private JTextField txtBomYellow;
	private JTextField txtBomRed;
	private JTextField txtBomGreen;
	private JTextField txtBomBlue;
	private JLabel labBombYellow;
	private JLabel labBombRed;
	private JLabel labBombBlue;
	private JLabel labBombGreen;
	private InterfazBombillos principal;
	
	
	
	public PanelDatos(InterfazBombillos ventana){
		principal = ventana;
		setBorder(BorderFactory.createTitledBorder("Informaci�n "));
		setLayout(new GridLayout(8,2));
		labCantBomb = new JLabel();
		labCantBomb.setIcon(new ImageIcon("./data/imagenes/white.gif"));
		labCantBomb.setHorizontalAlignment(JLabel.CENTER);
		labPosX = new JLabel("Posici�n X: ");
		labPosY = new JLabel("Posici�n Y: ");
		txtCantBomb = new JTextField();
		txtCantBomb.setEditable(false);
		txtPosY = new JTextField();
		txtPosX = new JTextField();
		botPrender = new JButton("<html>Prender Bombillo</html>");
		botPrimer = new JButton("<html>1er bombillo apagado</html>");
		txtBomYellow =  new JTextField();
		txtBomRed =  new JTextField();
		txtBomBlue =  new JTextField();
		txtBomGreen =  new JTextField();
		txtBomRed.setEditable(false);
		txtBomYellow.setEditable(false);
		txtBomBlue.setEditable(false);
		txtBomGreen.setEditable(false);
		labBombYellow = new JLabel();
		labBombYellow.setIcon(new ImageIcon("./data/imagenes/yellow.gif"));
		labBombRed = new JLabel();
		labBombRed.setIcon(new ImageIcon("./data/imagenes/red.gif"));
		labBombBlue = new JLabel();
		labBombBlue.setIcon(new ImageIcon("./data/imagenes/blue.gif"));
		labBombGreen = new JLabel();
		labBombGreen.setIcon(new ImageIcon("./data/imagenes/green.gif"));
		labBombBlue.setHorizontalAlignment(JLabel.CENTER);
		labBombGreen.setHorizontalAlignment(JLabel.CENTER);
		labBombRed.setHorizontalAlignment(JLabel.CENTER);
		labBombYellow.setHorizontalAlignment(JLabel.CENTER);
		labPosX.setHorizontalAlignment(JLabel.CENTER);
		labPosY.setHorizontalAlignment(JLabel.CENTER);
		
		botPrender.setActionCommand(PRENDER);
		botPrender.addActionListener(this);
		botPrimer.setActionCommand(PRIMER);
		botPrimer.addActionListener(this);
		
		
		this.add(labBombYellow);
		this.add(txtBomYellow);
		this.add(labBombBlue);
		this.add(txtBomBlue);
		this.add(labBombGreen);
		this.add(txtBomGreen);
		this.add(labBombRed);
		this.add(txtBomRed);
		this.add(labCantBomb);
		this.add(txtCantBomb);
		this.add(labPosX);
		this.add(txtPosX);
		this.add(labPosY);
		this.add(txtPosY);
		this.add(botPrender);
		this.add(botPrimer);
		
	}

	public void refrescarCantBomb(int cantApagados, int cantAzul, int cantVerde, int cantAmarillo, int cantRojo){
		txtCantBomb.setText(cantApagados+"");
		txtBomBlue.setText(cantAzul +"");
		txtBomGreen.setText(cantVerde+"");
		txtBomRed.setText(cantRojo+"");
		txtBomYellow.setText(cantAmarillo+"");
	}
	public void refrescarPosiciones(int posX, int posY){
		txtPosX.setText(posX+"");		
		txtPosY.setText(posY+"");
		txtPosX.setHorizontalAlignment(JTextField.CENTER);
		txtPosY.setHorizontalAlignment(JTextField.CENTER);
	}
	public void actionPerformed(ActionEvent e) {
	
		String comando = e.getActionCommand();
		if (comando.equals(PRENDER)) {
			principal.prenderBombillo();
		} else if (comando.equals(PRIMER)) {
			principal.primerBombilloApagado();
		}

	}
	public String darPosX(){
		return txtPosX.getText();
	}
	public String darPosY(){
		return txtPosY.getText();
	}
}
